"use strict";
// Fixture package: the marker is computed here so no script text carries it.
exports.marker = (n) => "lockfile-" + String((n * (n + 1)) / 2);
