from setuptools import setup
setup(name='vamfixture-sdist-only', version='1.0.0')
