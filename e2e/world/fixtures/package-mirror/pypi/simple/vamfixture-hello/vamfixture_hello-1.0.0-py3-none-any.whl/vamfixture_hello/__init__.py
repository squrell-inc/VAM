"""Fixture package: the marker is computed here so no script text carries it."""


def marker(n):
    return "lockfile-" + str(sum(range(n + 1)))
